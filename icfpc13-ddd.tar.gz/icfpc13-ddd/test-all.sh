ghc -e Main.run tests.hs

