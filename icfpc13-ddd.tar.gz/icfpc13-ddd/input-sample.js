[{"inputs":["0","1","2"]},{"size":["3"]},{"operators":["not"]}]
