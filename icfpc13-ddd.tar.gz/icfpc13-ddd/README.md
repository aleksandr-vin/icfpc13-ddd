# Dig Data Doom team's solution of the ICFPC'13
