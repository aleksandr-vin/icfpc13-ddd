package com.bigdatadoom.sender;

/**
 * User: Evgeniy.Chibirev
 */
public class UtilTest {


}
